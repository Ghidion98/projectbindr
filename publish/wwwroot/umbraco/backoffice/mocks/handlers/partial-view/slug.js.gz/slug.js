export const UMB_SLUG = '/partial-view';
