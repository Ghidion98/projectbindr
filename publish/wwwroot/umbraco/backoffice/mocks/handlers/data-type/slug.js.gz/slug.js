export const UMB_SLUG = '/data-type';
