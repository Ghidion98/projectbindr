export const UMB_SLUG = '/document-type';
