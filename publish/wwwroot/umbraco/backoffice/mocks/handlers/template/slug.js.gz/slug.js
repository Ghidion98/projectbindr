export const UMB_SLUG = '/template';
