export const UMB_SLUG = '/language';
