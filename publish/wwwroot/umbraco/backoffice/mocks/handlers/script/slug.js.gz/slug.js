export const UMB_SLUG = '/script';
