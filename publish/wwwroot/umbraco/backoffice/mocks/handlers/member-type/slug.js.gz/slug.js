export const UMB_SLUG = '/member-type';
