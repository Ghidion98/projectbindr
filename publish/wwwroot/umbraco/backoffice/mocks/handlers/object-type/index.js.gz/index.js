import { handlers as itemHandlers } from './item.handlers.js';
export const handlers = [...itemHandlers];
