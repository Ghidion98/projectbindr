export const UMB_SLUG = '/object-types';
