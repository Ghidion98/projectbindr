import{a as s,e}from"./index-Def4N_V2.js";export{s as monaco,e as styles};
